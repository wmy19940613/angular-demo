(function (angular) {
    // "use strict";

    // start your ride
    var app = angular.module('main', [
      'home',
      'in_theaters',
      'coming_soon',
      'top250'
      ])
})(angular);